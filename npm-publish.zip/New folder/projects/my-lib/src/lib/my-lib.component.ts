import { Component, OnInit,Input  } from '@angular/core';

@Component({
  selector: 'lib-my-lib',
  templateUrl: './my-lib.component.html',
  styles: [
  ]
})
export class MyLibComponent implements OnInit {
  data = [
    {id: 1, 'name': "United States"},
    {id: 2, 'name': "Australia"},
    {id: 3, 'name': "Canada"},
    {id: 4, 'name': "Brazil"},
    {id: 5, 'name': "England"}
  ];
  @Input() inputData: any;
  constructor() { }

  ngOnInit(): void {
  }

}
