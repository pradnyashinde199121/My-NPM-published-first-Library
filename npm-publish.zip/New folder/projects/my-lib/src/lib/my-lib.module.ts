import { NgModule } from '@angular/core';
import { MyLibComponent } from './my-lib.component';
import { BrowserModule } from '@angular/platform-browser'


@NgModule({
  declarations: [MyLibComponent],
  imports: [BrowserModule
  ],
  exports: [MyLibComponent]
})
export class MyLibModule { }
